// /src/app/ModernApp.js
import { Profiler, memo, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Platform, StatusBar as NativeStatusBar, View } from 'react-native';
import { SafeAreaProvider, SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { ThemeProvider, useTheme } from '../ui/theme/theme';
import { StoreProvider, StoreFreeze, useStore } from '../store/store';
import { IconBtn, T, useWide } from '../ui/ui';
import { Sidebar, SideMenu } from '../components/shell/Menus';
import { TopBar, TabBar } from '../components/shell/Bars';
import ScreenErrorBoundary from '../components/shell/ScreenErrorBoundary';
import Backup from '../screens/workspace/Backup';
import Overview from '../screens/overview/Overview';
import Board from '../screens/board/Board';
import Timeline from '../screens/timeline/Timeline';
import Tasks from '../screens/tasks/Tasks';
import TaskSheet from '../screens/tasks/TaskSheet';
import { Sprints, Releases, Testing } from '../screens/delivery/Delivery';
import { Resources, Costs, Automations, Reports, Activity, Settings } from '../screens/workspace/Workspace';
import { MAIN } from '../store/data';
import { Scheduling, TaskConfiguration, Collaboration, Specifications } from '../screens/management/Management';
import { Projects } from '../screens/governance/Projects';
import Portfolios from '../screens/governance/Portfolios';
import { Programs } from '../screens/governance/Programs';
import { diagnosticMonitor } from '../diagnostics/monitor';
import IslandNotice from '../components/notice/IslandNotice';
import { noticeTopOffset } from '../components/notice/noticePlacement.cjs';
import { shouldRenderPage, retainsHiddenTabs } from './navigation/pageRetention.cjs';
import { resolveVisited, addVisited } from './navigation/visitedTabs.cjs';

// Text can't be selected anywhere except in input fields (web, including phone browsers).
if (Platform.OS === 'web' && typeof document !== 'undefined' && !document.getElementById('no-select-style')) {
  const style = document.createElement('style');
  style.id = 'no-select-style';
  style.textContent =
    '*{-webkit-user-select:none;user-select:none;-webkit-touch-callout:none;-webkit-tap-highlight-color:transparent}' +
    'input,textarea{-webkit-user-select:text;user-select:text}';
  document.head.appendChild(style);
}

// Navigation mirrors the source app's 17 screens, grouped instead of one flat list.
const NAV = [
  {
    group: 'Plan',
    items: [
      ['overview', 'Overview', 'grid'],
      ['board', 'Board', 'columns'],
      ['timeline', 'Timeline', 'bar-chart-2'],
      ['scheduling', 'Scheduling', 'calendar'],
      ['tasks', 'Tasks', 'check-square'],
    ],
  },
  {
    group: 'Deliver',
    items: [
      ['sprints', 'Sprints', 'zap'],
      ['releases', 'Releases', 'tag'],
      ['testing', 'Testing', 'shield'],
    ],
  },
  {
    group: 'Team and money',
    items: [
      ['resources', 'Resources', 'users'],
      ['collaboration', 'Collaboration', 'message-circle'],
      ['costs', 'Costs', 'dollar-sign'],
    ],
  },
  {
    group: 'Governance',
    items: [
      ['projects', 'Projects', 'folder'],
      ['portfolios', 'Portfolios', 'layers'],
      ['programs', 'Programs', 'git-merge'],
    ],
  },
  {
    group: 'Operate',
    items: [
      ['taskconfig', 'Task configuration', 'sliders'],
      ['automations', 'Automations', 'cpu'],
      ['reports', 'Reports', 'pie-chart'],
      ['activity', 'Activity', 'activity'],
      ['specifications', 'Specifications', 'book-open'],
      ['backup', 'Backup', 'hard-drive'],
      ['settings', 'Settings', 'settings'],
    ],
  },
];

const SCREENS = {
  overview: Overview,
  board: Board,
  timeline: Timeline,
  scheduling: Scheduling,
  taskconfig: TaskConfiguration,
  collaboration: Collaboration,
  specifications: Specifications,
  tasks: Tasks,
  sprints: Sprints,
  releases: Releases,
  testing: Testing,
  resources: Resources,
  costs: Costs,
  projects: Projects,
  portfolios: Portfolios,
  programs: Programs,
  automations: Automations,
  reports: Reports,
  activity: Activity,
  backup: Backup,
  settings: Settings,
};

// Phone bottom bar: five primary screens. Everything else lives in the side menu.
const TABS = [
  ['overview', 'Overview', 'grid'],
  ['board', 'Board', 'columns'],
  ['timeline', 'Timeline', 'bar-chart-2'],
  ['tasks', 'Tasks', 'check-square'],
  ['sprints', 'Sprints', 'zap'],
];


// Only the active page subscribes to the workspace. Hidden screens otherwise
// recalculate charts and reconcile rows on every keystroke.
const CACHED_TABS = TABS.map(([id]) => id);
// Tripwire, not a workaround: Shell must mount exactly once per JS run. A second mount means something above it
// remounted the app (v0.5.12 root cause, see TimelineGestureHost). Fast Refresh also trips it in development.
let shellMounts = 0;
const DEFERRED_NATIVE_TABS = ['timeline', 'board', 'tasks', 'sprints'];
// Native retains visited primary tabs (a tab switch is a visibility toggle, not a rebuild). Hidden pages sit behind
// StoreFreeze, so they no longer re-render on every edit. Web keeps unmounting heavy hidden screens.
const retainHiddenTab = () => retainsHiddenTabs(Platform.OS);
const CachedPage = memo(function CachedPage({ pageId, active, openTask, go, query, openStatus, statusRequest }) {
  // Heavy native screens (Timeline SVG/gestures, Board cards, Tasks, Sprints): commit the tab change first so the
  // bar, title and press feedback respond at once, then mount the screen two frames later. Only the first visit pays;
  // afterwards the page stays mounted and hidden.
  const [ready, setReady] = useState(Platform.OS==='web' || !DEFERRED_NATIVE_TABS.includes(pageId));
  useEffect(() => {
    if (!active || ready) return undefined;
    let nextFrame = 0;
    const firstFrame = requestAnimationFrame(() => {
      nextFrame = requestAnimationFrame(() => setReady(true));
    });
    return () => { cancelAnimationFrame(firstFrame); cancelAnimationFrame(nextFrame); };
  }, [active, ready]);
  const shown = useRef(false);
  useEffect(() => {
    if (active && ready) {
      if (shown.current) diagnosticMonitor.recordAction(`tab shown from retained page: ${pageId}`);
      shown.current = true;
    }
  }, [active, ready, pageId]);
  const ScreenComponent = SCREENS[pageId];
  // The screen element keeps its identity when only `active` flips, so showing a retained page re-renders nothing
  // unless the store or its query really changed while it was hidden.
  const content = useMemo(() => ready
    ? <Profiler id={pageId} onRender={(_, __, duration) => diagnosticMonitor.recordRender(pageId, duration)}>
        <ScreenComponent openTask={openTask} go={go} query={query} openStatus={openStatus} statusRequest={statusRequest} />
      </Profiler>
    : <View accessible accessibilityLabel={`Opening ${pageId}`} style={{ flex:1,justifyContent:'center',alignItems:'center' }}><T size={13} muted>{`Preparing ${pageId}…`}</T></View>,
  [ready, pageId, ScreenComponent, openTask, go, query, openStatus, statusRequest]);
  return <View style={{ flex: 1, display: active ? 'flex' : 'none' }}>
    <StoreFreeze frozen={!active}>
      <ScreenErrorBoundary screenId={pageId} go={go}>{content}</ScreenErrorBoundary>
    </StoreFreeze>
  </View>;
}, (prev, next) => !shouldRenderPage(prev, next)); // memo's comparator answers "equal, skip?"

function Shell({}) {
  const { c, mode, setPref } = useTheme();
  const { addTask, switchProject, workspace, notice, dismissNotice } = useStore();
  const wide = useWide();
  const insets = useSafeAreaInsets();
  const [screen, setScreen] = useState('overview');
  const projectId = workspace.selectedId;
  const projectIdRef = useRef(projectId);
  projectIdRef.current = projectId;
  const [visitedState, setVisitedState] = useState({ projectId, list: ['overview'] });
  // After a project switch only the visible tab is rebuilt; other tabs mount lazily on their next visit.
  const visited = resolveVisited(visitedState, projectId, screen, CACHED_TABS);
  const [taskId, setTaskId] = useState(null);
  const [menu, setMenu] = useState(false);
  const [query, setQuery] = useState('');
  useEffect(() => {
    diagnosticMonitor.start();
    diagnosticMonitor.recordAction('shell mounted');
    shellMounts += 1;
    if (shellMounts > 1) diagnosticMonitor.recordAction(`UNEXPECTED SHELL REMOUNT #${shellMounts}`);
    diagnosticMonitor.recordScreen('overview');
    return () => diagnosticMonitor.recordAction('shell unmounted');
  }, []);
  const navigationRef = useRef({ screen: 'overview', at: Date.now() });
  const intentRef = useRef(null);
  if (!intentRef.current) intentRef.current = require('./navigation/navigationIntent.cjs').createNavigationIntent();
  useEffect(() => {
    const pending = navigationRef.current;
    // Two frames after committing the new tab approximates JS navigation paint latency.
    const first = requestAnimationFrame(() => {
      const second = requestAnimationFrame(() => diagnosticMonitor.recordTransition(pending.screen, Date.now()-pending.at));
      navigationRef.current.cancel = second;
    });
    return () => { cancelAnimationFrame(first); if(navigationRef.current.cancel) cancelAnimationFrame(navigationRef.current.cancel); };
  }, [screen]);

  const tabQueue = useRef(null);
  const go = useCallback((k, source = 'screen or menu') => {
    tabQueue.current?.clear();
    if (!SCREENS[k] || navigationRef.current.screen === k) return;
    const fromScreen = navigationRef.current.screen;
    diagnosticMonitor.recordAction(`navigation request: ${navigationRef.current.screen} -> ${k}; source=${source}`);
    intentRef.current.advance();
    navigationRef.current = { screen:k, at:Date.now() };
    diagnosticMonitor.recordScreen(k);
    setVisitedState(v => addVisited(v, projectIdRef.current, fromScreen, k, CACHED_TABS));
    setScreen(k);
    setMenu(false);
  }, []);
  if (!tabQueue.current) tabQueue.current = require('./navigation/navigationQueue.cjs').createNavigationQueue(
    requestAnimationFrame, cancelAnimationFrame, k => go(k, 'bottom tab'));
  const requestTab = useCallback(k => tabQueue.current.request(k), []);
  useEffect(() => () => tabQueue.current.clear(), []);
  const openTask = useCallback((id) => setTaskId(id), []);
  // Overview tiles: open Tasks already filtered to one status.
  const [statusRequest, setStatusRequest] = useState(null);
  const openStatus = useCallback((status) => { setStatusRequest({ status }); go('tasks'); }, [go]);
  // Picking a project opens it; a brand-new one starts on the Board so there is something to add to.
  const pickProject = useCallback((id, isNew) => {
    switchProject(id);
    setTaskId(null);
    setMenu(false);
    if (isNew) go('board');
  }, [switchProject, go]);
  // "Open project" from Portfolios / Programs: select the project, then show its governance detail in Projects.
  const [projectRequest, setProjectRequest] = useState(null);
  const openProject = useCallback((id) => {
    if (!switchProject(id)) return;
    setTaskId(null);
    setProjectRequest(id);
    go('projects');
  }, [switchProject, go]);
  const clearProjectRequest = useCallback(() => setProjectRequest(null), []);
  const toggleMode = () => setPref(mode === 'dark' ? 'light' : 'dark');
  const newTask = () => { const id=addTask('Untitled task', 'Backlog', MAIN); if(id)setTaskId(id); };
  const onQuery = (q) => {
    setQuery(q);
    if (q && screen !== 'tasks') go('tasks');
  };

  
  const page = <>
    {CACHED_TABS.filter(id => visited.includes(id) && (retainHiddenTab(id) || id === screen)).map(id =>
      <CachedPage key={`${workspace.selectedId}:${id}`} pageId={id} active={screen === id} openTask={openTask} go={go} query={query} openStatus={openStatus} statusRequest={statusRequest} />
    )}
    {!CACHED_TABS.includes(screen) ? (() => { const Current = SCREENS[screen]; return <ScreenErrorBoundary key={screen === 'projects' ? screen : `${workspace.selectedId}:${screen}`} screenId={screen} go={go}><Profiler id={screen} onRender={(_, __, duration) => diagnosticMonitor.recordRender(screen, duration)}><Current openTask={openTask} go={go} query={query} openStatus={openStatus} statusRequest={statusRequest} openProject={openProject} projectRequest={projectRequest} onProjectRequestHandled={clearProjectRequest} /></Profiler></ScreenErrorBoundary>; })() : null}
  </>;
  const sheet = taskId ? <TaskSheet key={`${workspace.selectedId}:${taskId}`} taskId={taskId} onClose={() => setTaskId(null)} /> : null;
  const barStyle = mode === 'dark' ? 'light' : 'dark';
  const screenTitle = NAV.flatMap(group=>group.items).find(([id])=>id===screen)?.[1] || 'Overview';

  if (wide) {
    return (
      <View style={{ flex: 1, flexDirection: 'row', backgroundColor: c.bg }}>
        <StatusBar style={barStyle} translucent={false} />
        <Sidebar nav={NAV} current={screen} go={go} onPickProject={pickProject} />
        <View style={{ flex: 1, minWidth: 0 }}>
          <TopBar query={query} onQuery={onQuery} onNew={newTask} mode={mode} onToggleMode={toggleMode} />
          <View style={{ flex: 1 }}>{page}</View>
        </View>
        {sheet}
        <IslandNotice notice={notice} onDismiss={dismissNotice} wide topOffset={Math.max(20, insets.top + 16)} />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, position: 'relative', backgroundColor: c.bg }}>
      <SafeAreaView edges={['top', 'bottom', 'left', 'right']} style={{ flex: 1, backgroundColor: c.bg }}>
        <StatusBar style={barStyle} translucent={false} />
        <View style={{ flexDirection:'row', alignItems:'center', justifyContent:'space-between', paddingHorizontal:18, paddingTop:17, paddingBottom:16, minHeight:83, gap:12 }}>
          <View style={{ flex:1, minWidth:0, flexDirection:'row', alignItems:'center', gap:12 }}>
            <IconBtn icon="menu" label="Open menu" onPress={() => setMenu(true)} />
            <T weight="700" size={19} color={c.ink} numberOfLines={1} style={{flexShrink:1, letterSpacing:-0.25}}>{screenTitle}</T>
          </View>
          <View style={{ flexDirection: 'row', gap: 8 }}>
            <IconBtn icon={mode === 'dark' ? 'sun' : 'moon'} label="Toggle theme" onPress={toggleMode} />
            <IconBtn icon="plus" label="New task" solid onPress={newTask} />
          </View>
        </View>
        <View style={{ flex: 1, minHeight: 0 }}>
          {page}
        </View>
        <TabBar tabs={TABS} current={screen} go={requestTab} intent={intentRef.current} />
        {sheet}
        <SideMenu nav={NAV} visible={menu} current={screen} go={go} onClose={() => setMenu(false)} onPickProject={pickProject} />
      </SafeAreaView>
      {/* Place the island at the top of the app, below the device status bar/cutout.
          Do not anchor it to the scrolling page or under the header. */}
      <IslandNotice
        notice={notice}
        onDismiss={dismissNotice}
        topOffset={noticeTopOffset(insets, Platform.OS, NativeStatusBar.currentHeight)}
      />
    </View>
  );
}

export default function ModernApp({}) {
  return (
    <SafeAreaProvider>
      <ThemeProvider>
        <StoreProvider>
          <Shell />
        </StoreProvider>
      </ThemeProvider>
    </SafeAreaProvider>
  );
}
