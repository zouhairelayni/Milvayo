# Niyarvo Projects — summary.md

**Batch:** 02 (patch on v0.5.15; app.json / package.json untouched)

## Done
- Batch 01 (Android, confirmed working by you): dragged bar follows the chart scroll; auto-scroll always stops on release.
- Batch 02 (Web): dragging and resizing bars on the web version.
  - Cause: phone browsers cancel a touch drag ("pointercancel") a few finger moves after a long-press, because the browser starts panning the page. Checked in real Chromium with touch emulation: cancel after 3 moves; a touchmove handler added at lift stops it (24/24 moves delivered).
  - Fix: web hook now blocks the browser pan, text selection and long-press menu while a bar is lifted.
  - Same stuck-drag protection as Android on web: unmount mid-drag ends the drag, per-frame heartbeat, Timeline watchdog now covers web too.

## In progress
- Nothing.

## Next tasks
- Test web on your phone browser and on a computer browser (steps in the chat), then send feedback.

## Files changed (batch 02)
- src/gesture.web.js
- src/screens/Timeline.js (watchdog no longer skipped on web)
- tests/timeline-drag-scroll-0515.test.cjs (+1 test, 8 total)
- docs/changelogs/modern-code/CHG-NP-0.5.15-timeline-drag-scroll.md (web section added)

## Test results
- node --test: 452 pass, 1 skipped, 0 fail (source-level). JSX syntax clean.
- Chromium touch experiment on a stand-in page: confirmed the cause and the fix mechanism.
- Real web app run: **Not run**. Device run of batch 02: **Not run**.

## Open issues
- On web a moved bar jumps in whole days (as before), it does not slide smoothly.
- If web still fails, send: device/browser, what you did, any console error text.
