'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
test('unused store actions are removed; the ones the UI uses remain',()=>{
 const s=fs.readFileSync(path.join(__dirname,'..','src/store.js'),'utf8');
 for(const n of ['moveList:','moveTaskToList:','setGovernanceDoc:'])assert.ok(!s.includes('  '+n));
 for(const n of ['moveListTo:','setGovernanceDocValue:','setGovernanceDocStatus:'])assert.ok(s.includes('  '+n));
});
