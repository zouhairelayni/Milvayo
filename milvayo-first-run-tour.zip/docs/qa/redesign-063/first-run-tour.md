# QA and rollback: first-run tour (redesign 0.6.3)

No package, storage key, data format or migration change. Direct edits only: no build, commit or push.

## Automated
`npm test` (expect the same failures as before this change; none new), JSX syntax of the five app files, `npx expo install --check`.

## Check on a device (not run by the author)
1. **Fresh install** (clear app data first, export a backup if you want to keep your workspace): the tour opens over Overview as soon as the app is ready. Swipe through the three slides, then Next, Choose a starter, pick each starter once, Continue, type a name, Create project. Expected landing: Board for Board and Blank, Timeline for Timeline, Sprints for Sprints. Board, Timeline and Blank hide Sprints, Releases and Testing for that project only; More > Manage tools turns them back on.
2. **Skip** on every step leaves the sample project and its tools exactly as before.
3. **Upgrade**: open the app on existing data. The tour must NOT appear. This is the most important check.
4. **More > Take the tour** reopens it on any install; Skip and finish both work.
5. Android: Back button behaviour while the tour is open, keyboard over the name step (Create project stays reachable), font scale 130%, Light/Dark/AMOLED, Remove animations.
6. Web: wide window shows the tour in a 520px column; Enter in the name field creates the project.
7. Island notices still appear above the tour.

## Roll back
Delete `src/screens/onboarding/` and `src/components/illustrations/TourArtwork.js`, then remove the three marked blocks in `ModernApp.js` (import block, tour state/handler, render line) and the one row in `More.js`. Nothing in storage depends on the tour.
