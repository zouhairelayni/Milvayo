// /tests/app/first-run-tour.test.cjs
'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const read = (f) => fs.readFileSync(path.join(__dirname, '../..', f), 'utf8');
const app = read('src/app/ModernApp.js');
const tour = read('src/screens/onboarding/Onboarding.js');
const probe = read('src/screens/onboarding/freshInstall.js');
const events = require('../../src/screens/onboarding/tourEvents.cjs');

test('the fresh-install read is issued at module load, before any render and before the store can write', () => {
  assert.match(probe, /AsyncStorage\.multiGet\(\[INDEX_KEY, MAIN_KEY\]\)/);
  assert.match(probe, /isFreshInstall\(index, main\)\) markFreshInstall\(\)/);
  assert.match(probe, /\.catch\(\(\) => \{\}\)/, 'a failed read means no tour, never a crash');
  assert.match(probe, /^export const freshInstallProbe =/m, 'evaluated on import, not inside a component or effect');
  assert.match(app, /^import '\.\.\/screens\/onboarding\/freshInstall';$/m);
  assert.doesNotMatch(probe, /setItem|multiSet|removeItem|clear\(/, 'read only');
  assert.match(read('src/store/workspaces.cjs'), /INDEX_KEY = 'niyarvo-workspaces-v1'/, 'storage keys are untouched');
});

test('finishing creates one project with createProject, applies the starter with setProjectTool and opens its screen', () => {
  const fin = app.slice(app.indexOf('const finishTour'), app.indexOf('const newTask'));
  assert.match(fin, /createProject\(\{ name \}\)/);
  assert.match(fin, /if \(!id\) return;/);
  assert.match(fin, /plan\.off\.forEach\(tool => setProjectTool\(tool, false\)\)/);
  assert.match(fin, /go\(plan\.screen, 'first-run starter'\)/);
  assert.doesNotMatch(fin, /deleteProject|restoreWorkspace|importProject|AsyncStorage|setItem/);
  assert.match(app, /const \{ addTask, switchProject, workspace, workspaceId, notice, dismissNotice \} = useStore\(\);/, 'the existing store destructuring is untouched');
});

test('skip closes the tour and calls no store action; island notices stay above it', () => {
  assert.match(app, /<Onboarding onSkip=\{\(\) => setTouring\(false\)\} onFinish=\{finishTour\} \/>/);
  assert.ok(app.indexOf('<Onboarding') < app.indexOf('<IslandNotice'));
  assert.match(tour, /onPress=\{onSkip\}/);
  assert.match(app, /useState\(takeFreshInstall\)/);
});

test('More can reopen the tour and keeps every existing row', () => {
  const more = read('src/screens/more/More.js');
  assert.match(more, /label="Take the tour" last=\{false\} onPress=\{requestTour\}/);
  for (const keep of ['label="Appearance"', '<Row icon="monitor" label="Desktop layout"', 'label="Manage tools"', 'placeholder="Find a workspace tool"']) assert.ok(more.includes(keep), keep);
  let n = 0; const off = events.subscribeTour(() => { n += 1; });
  events.requestTour(); events.requestTour(); off(); events.requestTour();
  assert.equal(n, 2);
  assert.match(app, /useEffect\(\(\) => subscribeTour\(\(\) => setTouring\(true\)\), \[\]\)/);
});

test('the fresh-install flag opens the tour once: waiting for the shell, or at once when it already listens', () => {
  assert.equal(events.takeFreshInstall(), false);
  events.markFreshInstall();
  assert.equal(events.takeFreshInstall(), true);
  assert.equal(events.takeFreshInstall(), false, 'consumed once');
  let opened = 0; const off = events.subscribeTour(() => { opened += 1; });
  events.markFreshInstall();
  off();
  assert.equal(opened, 1);
  assert.equal(events.takeFreshInstall(), false, 'no stale flag left behind');
});

test('every tour control is present, labelled and at least 44px; the tour uses the app kit and no new package', () => {
  for (const label of ['Skip the tour', 'Back', "'Choose a starter'", "'Next'", '"Continue"', '"Create project"', 'placeholder="Project name"'])
    assert.ok(tour.includes(label), label);
  for (const needle of ['accessibilityRole="radio"', 'accessibilityRole="radiogroup"', 'accessibilityViewIsModal', 'minHeight: 44', 'pagingEnabled', 'disabled={!validName(name)}', 'keyboardShouldPersistTaps="handled"'])
    assert.ok(tour.includes(needle), needle);
  for (const used of ['ui/PressSurface', 'ui/Reveal', 'ScreenIntro', 'illustrations/TourArtwork']) assert.ok(tour.includes(used), used);
  assert.doesNotMatch(tour, /Animated|reanimated|useSharedValue/, 'motion comes only from Reveal and PressSurface');
  const deps = JSON.parse(read('package.json')).dependencies;
  for (const d of ['react-native-svg', 'react-native-safe-area-context', '@react-native-async-storage/async-storage']) assert.ok(deps[d], d);
});
