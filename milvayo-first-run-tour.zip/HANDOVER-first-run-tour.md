# Handover: first-run tour on the redesign (v0.6.3)

Base: `milvayo.zip` (package version 0.6.3). This package holds only new and touched files, laid out from the project root; copy them over the project. The earlier tour for the 0.5.59 base (`milvayo-batch-04.zip`) is superseded by this one for this base: it used a separate motion and art kit that the redesign now provides itself.

## What changed
| Area | Change | Files |
|---|---|---|
| Tour screen | slides, starter picker, name step, Skip everywhere | `src/screens/onboarding/Onboarding.js` |
| Rules | slides, starters (`off` tool lists, landing screen), name validation, step order, fresh-install rule | `src/screens/onboarding/onboardingPlan.cjs` |
| Events | "Take the tour" and the fresh flag, without props | `src/screens/onboarding/tourEvents.cjs` |
| Fresh detection | read-only probe at module load | `src/screens/onboarding/freshInstall.js` |
| Art | five drawings in the EmptyArtwork language | `src/components/illustrations/TourArtwork.js` |
| Wiring | import block, `touring` state + `finishTour`, one render line before `IslandNotice` | `src/app/ModernApp.js` |
| More | row "Take the tour" before Appearance | `src/screens/more/More.js` |
| Tests | 15 new | `tests/{domain,app,ui}/...` |
| Docs | changelog entry, QA/rollback, this file | `docs/changelog/CHANGELOG.md`, `docs/qa/redesign-063/first-run-tour.md` |

## Decisions worth knowing
- The fresh-install read happens at **module load** (`import '../screens/onboarding/freshInstall'`), not in `ColdStartGate`, because this base mounts `StoreProvider` immediately and the store writes the sample workspace on first launch. A read issued from an effect could race that write. Fresh means both `niyarvo-workspaces-v1` and `milvayo-v1` are empty.
- The tour reuses `createProject` and `setProjectTool`; it adds no store action and no field. Starters only switch tools off per project (reversible).
- Motion is only `Reveal` and `PressSurface`, so reduced-motion handling and press feel match the rest of the redesign. No `Animated` or Reanimated code in the tour.
- `ColdStartGate`, the store, the model, storage keys and `package.json` are untouched.

## Verification
- Same 62 failing tests before and after (all pre-existing on the unmodified base: stale assertions, `.github` file absent, and my test-only Babel stand-in); 742 pass; none new. Run `npm test` on Termux for the real baseline.
- Five touched or new app files parse. Rendered in a browser stand-in with the real `ui` kit; flow driven end to end.
- **Not run:** Expo Go, device, bundles, native animation, `freshInstall` on a real fresh install.

## Next, in the agreed order
Home = Today (tour entry already in More), then Releases/Testing/Sprints, Resources/Costs/Reports, Automations, Scheduling/Collaboration/Specifications, Settings/Backup, Projects/Portfolios/Programs. Each needs a preserved-controls test per screen first.
