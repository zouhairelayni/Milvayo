// /src/screens/onboarding/tourEvents.cjs
'use strict';
// A tiny event hub between the cold-start gate, the shell and the More screen, so none of them needs new props or context.
//  - requestTour(): "Take the tour" in More asks the shell to open the tour.
//  - markFreshInstall(): the cold-start gate saw a true first launch. If the shell is already listening it opens at once,
//    otherwise the flag waits for the shell's first render (takeFreshInstall).
const listeners = new Set();
let fresh = false;
const subscribeTour = (fn) => { listeners.add(fn); return () => { listeners.delete(fn); }; };
const requestTour = () => { listeners.forEach((fn) => fn()); };
const markFreshInstall = () => { if (listeners.size) requestTour(); else fresh = true; };
const takeFreshInstall = () => { const was = fresh; fresh = false; return was; };
module.exports = { subscribeTour, requestTour, markFreshInstall, takeFreshInstall };
