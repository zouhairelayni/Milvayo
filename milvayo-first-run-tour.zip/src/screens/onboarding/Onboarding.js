// /src/screens/onboarding/Onboarding.js
import { useRef, useState } from 'react';
import { ScrollView, View, useWindowDimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useTheme } from '../../ui/theme/theme';
import { Button, IconBtn, Input, ScreenIntro, T } from '../../ui/ui';
import PressSurface from '../../ui/PressSurface';
import Reveal from '../../ui/Reveal';
import TourArtwork from '../../components/illustrations/TourArtwork';
const { SLIDES, STARTERS, DEFAULT_STARTER, starterPlan, validName, stepBefore } = require('./onboardingPlan.cjs');

// First-run tour: three swipeable slides, a starter, a project name. Skip is on every step and leaves the sample project alone.
// The pager is a plain paging ScrollView and every motion is the app's own Reveal and PressSurface (opacity and transform only).
const Cta = ({ label, onPress, disabled }) => (
  <View style={{ flexDirection: 'row', justifyContent: 'center', padding: 20 }}>
    <Button label={label} onPress={onPress} disabled={disabled} />
  </View>
);

export default function Onboarding({ onSkip, onFinish }) {
  const { c } = useTheme();
  const insets = useSafeAreaInsets();
  const { width: screenWidth } = useWindowDimensions();
  const w = Math.min(screenWidth, 520);
  const [step, setStep] = useState('tour');
  const [slide, setSlide] = useState(0);
  const [starter, setStarter] = useState(DEFAULT_STARTER);
  const [name, setName] = useState('');
  const pager = useRef(null);
  const plan = starterPlan(starter);
  const lastSlide = slide === SLIDES.length - 1;
  const goSlide = (i) => { setSlide(i); pager.current?.scrollTo({ x: i * w, animated: true }); };
  const submit = () => { if (validName(name)) onFinish({ name: name.trim(), starterId: starter }); };

  return (
    <View accessibilityViewIsModal style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, zIndex: 20, backgroundColor: c.bg, alignItems: 'center' }}>
      <View style={{ flex: 1, width: '100%', maxWidth: 520, paddingTop: insets.top, paddingBottom: insets.bottom }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 12, minHeight: 60 }}>
          {step !== 'tour' ? <IconBtn icon="chevron-left" label="Back" onPress={() => setStep(stepBefore(step))} /> : <View style={{ width: 44 }} />}
          <PressSurface accessibilityRole="button" accessibilityLabel="Skip the tour" onPress={onSkip} hitSlop={4}
            style={{ minHeight: 44, paddingHorizontal: 14, justifyContent: 'center' }}>
            <T size={14} weight="600" muted>Skip</T>
          </PressSurface>
        </View>

        {step === 'tour' ? <>
          <ScrollView ref={pager} horizontal pagingEnabled showsHorizontalScrollIndicator={false} style={{ flex: 1 }}
            onMomentumScrollEnd={(e) => setSlide(Math.max(0, Math.min(SLIDES.length - 1, Math.round(e.nativeEvent.contentOffset.x / w))))}>
            {SLIDES.map((s) => (
              <View key={s.id} style={{ width: w, paddingHorizontal: 28, alignItems: 'center', justifyContent: 'center', gap: 24 }}>
                <TourArtwork kind={s.art} size={Math.min(w - 56, 300)} />
                <View style={{ gap: 8, alignItems: 'center' }}>
                  <T size={26} weight="600" center accessibilityRole="header">{s.title}</T>
                  <T size={14} muted center style={{ maxWidth: 320, lineHeight: 21 }}>{s.body}</T>
                </View>
              </View>
            ))}
          </ScrollView>
          <View accessible accessibilityLabel={`Slide ${slide + 1} of ${SLIDES.length}`} style={{ flexDirection: 'row', justifyContent: 'center', gap: 6 }}>
            {SLIDES.map((s, i) => <View key={s.id} style={{ width: i === slide ? 22 : 6, height: 6, borderRadius: 3, backgroundColor: i === slide ? c.ink : c.line }} />)}
          </View>
          <Cta label={lastSlide ? 'Choose a starter' : 'Next'} onPress={() => (lastSlide ? setStep('start') : goSlide(slide + 1))} />
        </> : null}

        {step === 'start' ? <>
          <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 20, gap: 20 }}>
            <Reveal><ScreenIntro title="What are you managing?" description="Pick a starting point. Switch tools on or off any time in More" /></Reveal>
            <View accessibilityRole="radiogroup" style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 12 }}>
              {STARTERS.map((s, i) => {
                const on = s.id === starter;
                return (
                  <Reveal key={s.id} delay={60 + i * 40} style={{ width: (w - 40 - 12) / 2 }}>
                    <PressSurface accessibilityRole="radio" accessibilityLabel={`${s.label}. ${s.hint}`} accessibilityState={{ checked: on }} onPress={() => setStarter(s.id)}
                      style={{ borderWidth: 1, borderColor: on ? c.ink : c.line, backgroundColor: on ? c.selection : c.surface, borderRadius: 18, padding: 12, gap: 6, alignItems: 'center' }}>
                      <TourArtwork kind={s.art} size={104} />
                      <T weight="600">{s.label}</T>
                      <T size={12} muted center style={{ lineHeight: 17 }}>{s.hint}</T>
                    </PressSurface>
                  </Reveal>
                );
              })}
            </View>
          </ScrollView>
          <Cta label="Continue" onPress={() => setStep('name')} />
        </> : null}

        {step === 'name' ? (
          <ScrollView keyboardShouldPersistTaps="handled" style={{ flex: 1 }} contentContainerStyle={{ padding: 20, gap: 16 }}>
            <Reveal><ScreenIntro title="Name your project" description={`${plan.label} starter. ${plan.hint}`} /></Reveal>
            <Reveal delay={60}><Input value={name} onChangeText={setName} autoFocus placeholder="Project name" accessibilityLabel="Project name" onSubmitEditing={submit} /></Reveal>
            <Cta label="Create project" onPress={submit} disabled={!validName(name)} />
          </ScrollView>
        ) : null}
      </View>
    </View>
  );
}
