// /src/screens/onboarding/freshInstall.js
import AsyncStorage from '@react-native-async-storage/async-storage';
const { INDEX_KEY, MAIN_KEY } = require('../../store/workspaces.cjs');
const { isFreshInstall } = require('./onboardingPlan.cjs');
const { markFreshInstall } = require('./tourEvents.cjs');

// Imported once by the app root. The read is issued while the module graph loads, before any React render, so it is queued
// ahead of the store's first write and sees the storage exactly as the previous session left it. Only a storage with neither
// workspace key counts as a first launch; any older install keeps one of the two keys. A failed read means no tour.
export const freshInstallProbe = AsyncStorage.multiGet([INDEX_KEY, MAIN_KEY])
  .then(([[, index], [, main]]) => { if (isFreshInstall(index, main)) markFreshInstall(); })
  .catch(() => {});
